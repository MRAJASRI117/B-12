import random

from flask import Flask, render_template, request, session, url_for
import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from werkzeug.utils import redirect
from sklearn.model_selection import train_test_split
from sklearn import tree
from sklearn.metrics import accuracy_score,precision_score,recall_score
from sklearn import linear_model
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression

import csv
from datetime import datetime
from datetime import date
from dateutil.parser import parse
import string
from nltk.corpus import stopwords
import nltk
from collections import OrderedDict
import pygal

import re
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload',methods=["POST","GET"])
def uploaddataset_csv_submitted():
    if request.method == "POST":
        csvfile = request.files['csvfile']
        result = csvfile.filename
        print(result)
        file = 'dataset/'+result
        print(file)
        session['filepath'] = file

        return render_template('uploaddataset.html',msg='sucess')
    return render_template('uploaddataset.html')


@app.route('/viewdata',methods=["POST","GET"])
def viewdata():
    session_var_value = session.get('filepath')
    df = pd.read_csv(session_var_value,encoding='latin-1')
    #print(df)
    x = pd.DataFrame(df)

    return render_template("view.html", data=x.to_html())

@app.route('/preprocess',methods=["POST","GET"])
def preprocessdata():
    session_var_value = session.get('filepath')
    df = pd.read_csv(session_var_value,encoding='latin-1')
    #print(df)
    x = pd.DataFrame(df)
    data = df.drop(['latitude', 'longitude', 'source_r', 'emoji_names'], axis=1)
    data.to_csv(r"dataset/preprocess.csv")
    users = {}
    with open('dataset/twitter.csv', 'r') as infile:

        rows = csv.reader(infile)
        for row in rows:
            if (not (row[1] == 'created')):
                date1 = datetime.date(parse(row[1].replace('/', '-')))
                date2 = datetime.date(datetime.now())
                delta = date2 - date1
                days = delta.days
                users[row[0]] = days
    print(users)
    with open(r'dataset\consolidated.csv', 'w', newline='') as csvfile:
        filewriter = csv.writer(csvfile, delimiter=',', quotechar='|', quoting=csv.QUOTE_MINIMAL)
        filewriter.writerow(
            ['Tweet Id', 'Account Age', 'No. Follower', 'No. Following', 'No. Userfavourites', 'No. Tweets',
             'No. Retweets', 'No. Hashtags', 'No. Url', 'No. Char', 'No. Digits', 'No. Non Ascii'])
        tweetid = df.groupby('tweetid')['followers'].sum()
        followers = df.groupby('tweetid')['followers'].sum()
        following = df.groupby('tweetid')['following'].sum()
        favourites = df.groupby('tweetid')['favorites'].sum()
        hashtag = df.groupby('tweetid')['hashtag'].count()
        tweets = df.groupby('tweetid')['tweetid'].count()
        retweets = df.groupby('tweetid')['retweets'].sum()
        urls = df.groupby('tweetid')['url'].count()
        textchars = df.groupby('tweetid')['text'].nth(0)
        length = []
        digits = []
        alpha = []
        asci = []
        for text in textchars:
            dcount = 0
            acount = 0
            ascount = 0
            for char in text:
                if char.isdigit():
                    dcount += 1
                elif char.isalpha():
                    acount += 1
                elif char.isspace():
                    pass
                else:
                    ascount += 1
            digits.append(dcount)
            alpha.append(acount)
            asci.append(ascount)

        norecords = len(tweetid)
        print(norecords)
        index = 0
        keys = tweetid.keys()
        for i in keys:
            row = []
            row.append(i)
            row.append(users.get(str(i)))
            row.append(followers.get(i))
            row.append(following.get(i))
            row.append(favourites.get(i))
            row.append(tweets.get(i))
            row.append(retweets.get(i))
            row.append(hashtag.get(i))
            row.append(urls.get(i))
            row.append(alpha[index])
            row.append(digits[index])
            row.append(asci[index])
            index += 1
            filewriter.writerow(row)
    x = pd.read_csv("dataset/consolidated.csv")
    return render_template("preprocess.html", data=x.to_html())

@app.route('/topspamham',methods=["POST","GET"])
def topspamham():
    cons = pd.read_csv("dataset/twitter.csv", encoding='latin-1')
    positive = cons['text' and cons['class'] == 'positive']
    positive = positive['text']
    negative = cons['text' and cons['class'] == 'negative']
    negative = negative['text']
    neutral = cons['text' and cons['class'] == 'neutral']
    neutral = neutral['text']

    positivetext = ''
    for text in positive:
        positivetext += text

    negativetext = ''
    for text in negative:
        negativetext += text

    neutraltext = ''
    for text in neutral:
            neutraltext += text

    positivetext = positivetext.replace("[^\w\s]", "").lower()
    positivetext = ' '.join([word for word in positivetext.split() if word not in (stopwords.words('english'))])
    positivetext = re.sub(r'[^\w\s]', '', positivetext)

    negativetext = negativetext.replace("[^\w\s]", "").lower()
    negativetext = ' '.join([word for word in negativetext.split() if word not in (stopwords.words('english'))])
    negativetext = re.sub(r'[^\w\s]', '', negativetext)

    neutraltext = neutraltext.replace("[^\w\s]", "").lower()
    neutraltext = ' '.join([word for word in neutraltext.split() if word not in (stopwords.words('english'))])
    neutraltext = re.sub(r'[^\w\s]', '', neutraltext)

    word2count = {}
    positivewords = positivetext.split(" ")
    for word in positivewords:
        if (len(word) >= 4):
            if word not in word2count.keys():
                word2count[word] = 1
            else:
                word2count[word] += 1
    # print(word2count)
    od = OrderedDict(sorted(word2count.items(), key=lambda x: x[1]))
    count = 0
    length = len(od)
    toppositivewords = ['TOP POSITIVE WORDS']
    for item in od.items():
        count += 1
        if (count > length - 30):
            toppositivewords.append(item[0])
    toppositivedf = pd.DataFrame(toppositivewords)

    word2count = {}
    negativewords = negativetext.split(" ")
    for word in negativewords:
        if (len(word) >= 4):
            if word not in word2count.keys():
                word2count[word] = 1
            else:
                word2count[word] += 1
    # print(word2count)
    od = OrderedDict(sorted(word2count.items(), key=lambda x: x[1]))
    count = 0
    length = len(od)
    topnegativewords = ['TOP NEGATIVE WORDS']
    for item in od.items():
        count += 1
        if (count > length - 30):
            topnegativewords.append(item[0])
    topnegativedf = pd.DataFrame(topnegativewords)

    word2count = {}
    neutralwords = neutraltext.split(" ")
    for word in neutralwords:
        if (len(word) >= 4):
            if word not in word2count.keys():
                word2count[word] = 1
            else:
                word2count[word] += 1
    # print(word2count)
    od = OrderedDict(sorted(word2count.items(), key=lambda x: x[1]))
    count = 0
    length = len(od)
    topneutralwords = ['TOP NEUTRAL WORDS']
    for item in od.items():
        count += 1
        if (count > length - 30):
            topneutralwords.append(item[0])
    topneutraldf = pd.DataFrame(topneutralwords)

    combineddf = pd.concat([toppositivedf,topnegativedf,topneutraldf],axis=1)
    combineddf.index += 1

    return render_template("topspamham.html", data=combineddf.to_html(header=False))

@app.route('/modelperformance',methods=["POST","GET"])
def modelperformance():
    global cv,model1,precision,recall, model2
    global accuracyscore ;
    global accuracyscore1,precision1,recall1 ;
    global accuracyscore2,precision2,recall2 ;
    global accuracyscore3,precision3,recall3 ;
    global accuracyscore4,precision4,recall4 ;
    global accuracyscore5,precision5,recall5 ;
    global accuracyscore6,precision6,recall6 ;


    session_var_value = session.get('filepath')
    df = pd.read_csv(session_var_value,encoding='latin-1')
    #print(df)
    X = df['text']
    y = df['class']
    X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.3,random_state=52)
    random.seed(10)
    random.random()
    cv = CountVectorizer(strip_accents='ascii', token_pattern=u'(?ui)\\b\\w*[a-z]+\\w*\\b', lowercase=True,
                         stop_words='english')
    X_trains = cv.fit_transform(X_train)
    X_tests = cv.transform(X_test)


    if request.method == "POST":
        selectedalg = int(request.form['algorithm'])

        if (selectedalg == 1):
            model1 = SVC(kernel='linear')
            model1.fit(X_trains, y_train)
            y_pred = model1.predict(X_tests)
            accuracyscore = accuracy_score(y_test, y_pred)
            precision = precision_score(y_test, y_pred, average='macro')
            recall = recall_score(y_test, y_pred, average='macro')
            # accuracy_score = model.score(X_trains,y_trains)
            print(accuracyscore)
            return render_template('modelperformance.html', msg="accuracy_score", score=round(accuracyscore,2), recall=round(recall,2), precision=round(precision,2),model="SVM with Kernel")
        if (selectedalg == 2):
            model2 = MLPClassifier(solver='lbfgs', alpha=1e-1, hidden_layer_sizes=(5, 2), random_state=1)
            model2.fit(X_trains, y_train)
            y_pred = model2.predict(X_tests)
            accuracyscore1 = accuracy_score(y_test, y_pred)
            precision1 = precision_score(y_test, y_pred, average='macro')
            recall1 = recall_score(y_test, y_pred, average='macro')
            # accuracy_score = model.score(X_trains,y_trains)
            print(accuracyscore)
            return render_template('modelperformance.html', msg="accuracy_score", score=round(accuracyscore1,2),recall=round(recall1,2), precision=round(precision1,2), model="Neural Network")

        if (selectedalg == 3):
            model3 = GradientBoostingClassifier(n_estimators=2, learning_rate=0.75, max_features=2, max_depth=2, random_state=0)
            model3.fit(X_trains, y_train)
            y_pred = model3.predict(X_tests)
            accuracyscore2 = accuracy_score(y_test, y_pred)
            # accuracy_score = model.score(X_trains,y_trains)
            precision2 = precision_score(y_test, y_pred, average='macro')
            recall2 = recall_score(y_test, y_pred, average='macro')
            print(accuracyscore)
            return render_template('modelperformance.html', msg="accuracy_score", score=round(accuracyscore2,2),recall=round(recall2,2), precision=round(precision2,2),model="Gradient Boost")

        if (selectedalg == 4):

            model4 = RandomForestClassifier(n_estimators=1)
            model4.fit(X_trains, y_train)
            y_pred = model4.predict(X_tests)
            accuracyscore3 = accuracy_score(y_test, y_pred)
            # accuracy_score = model.score(X_trains,y_trains)
            precision3 = precision_score(y_test, y_pred, average='macro')
            recall3 = recall_score(y_test, y_pred, average='macro')
            print(accuracyscore)
            return render_template('modelperformance.html', msg="accuracy_score", score=round(accuracyscore3,2),recall=round(recall3,2), precision=round(precision3,2),model="RandomForest")
        if (selectedalg == 5):
            model2=DecisionTreeClassifier()
            model2.fit(X_trains, y_train)
            y_pred = model2.predict(X_tests)
            accuracyscore4 = accuracy_score(y_test, y_pred)
            # p31 = precision_score(y_test, y_pred, average='macro')
            precision4 = precision_score(y_test, y_pred, average='macro')
            recall4 = recall_score(y_test, y_pred, average='macro')
            return render_template('modelperformance.html', msg="accuracy_score", score=round(accuracyscore4,2),recall=round(recall4,2), precision=round(precision4,2),model="Decision Tree")
        if (selectedalg == 6):

            from xgboost import XGBClassifier
            from sklearn.naive_bayes import GaussianNB
            model = GaussianNB()
            print(type(X_trains))
            model.fit(X_trains.toarray(), y_train)
            y_pred = model.predict(X_tests.toarray())
            accuracyscore5 = accuracy_score(y_test, y_pred)
            precision5 = precision_score(y_test, y_pred, average='macro')
            recall5 = recall_score(y_test, y_pred, average='macro')
            print("*************")
            return render_template('modelperformance.html', msg="accuracy_score", score=round(accuracyscore5,2),recall=round(recall5,2), precision=round(precision5,2), model="Naive Bayes")
        if (selectedalg == 7):
            from sklearn.neighbors import KNeighborsClassifier
            from sklearn.naive_bayes import GaussianNB
            model = KNeighborsClassifier(n_neighbors=10)
            print(type(X_trains))
            model.fit(X_trains.toarray(), y_train)
            y_pred = model.predict(X_tests.toarray())
            accuracyscore6 = accuracy_score(y_test, y_pred)
            precision6 = precision_score(y_test, y_pred, average='macro')
            recall6 = recall_score(y_test, y_pred, average='macro')
            print("*************")
            return render_template('modelperformance.html', msg="accuracy_score", score=round(accuracyscore6, 2),
                                   recall=round(recall6, 2), precision=round(precision6, 2), model="KNN")

    return render_template('modelperformance.html')

@app.route('/prediction',methods=["POST","GET"])
def prediction():
    global accuracy,precision,recall
    if request.method == "POST":
        tweet = request.form['tweet']
        X_test_cv = cv.transform([tweet])
        predictiontrain = model2.predict(X_test_cv)
        print('Predictions: ', predictiontrain)
        return render_template('prediction.html',msg="success",model="Random Forest With Kernel",predictions=predictiontrain)
    return render_template('prediction.html')

import pygal
@app.route('/bar_chart')
def bar():
    print('&&&&&&&&&&&&&&&&&&&&')
    line_chart = pygal.Bar()
    line_chart.title = 'ACCURACY, PRECISION AND RECALL SCORES'
    line_chart.add('Accuracy', [accuracyscore, accuracyscore1, accuracyscore2, accuracyscore3, accuracyscore4, accuracyscore5,accuracyscore5])
    line_chart.add('Precision', [precision, precision1, precision2, precision3, precision4, precision5,precision6])
    line_chart.add('Recall', [recall, recall1, recall2, recall3, recall4, recall5,recall6])
    # line_chart.add('SVM',[accuracyscore,precision,recall] )
    # line_chart.add('Neural Network',[accuracyscore1,precision1,recall1] )
    # line_chart.add('Gradient Boosting',[accuracyscore2,precision2,recall2])
    # line_chart.add('Random Forest',[accuracyscore3,precision3,recall3])
    # line_chart.add('Decision Tree',[accuracyscore4,precision4,recall4] )
    # line_chart.add('Naive Bayes',[accuracyscore5,precision5,recall5])
    line_chart.x_labels = ['SVM','Neural Network','Gradient Boosting','Random Forest','Decision Tree','Naive Bayes','KNN']
    print("5555555555555555",type(line_chart))
    graph_data = line_chart.render_data_uri()
    return render_template("bar_chart.html", graph_data=graph_data)

@app.route('/tables')
def tables():
    df = pd.read_csv(r"dataset\twitter.csv",encoding='latin-1')
    c1df = df[df['location'] == 'Mumbai']

    posc1df = c1df[df['class'] == 'positive']
    negc1df = c1df[df['class'] == 'negative']
    neuc1df = c1df[df['class'] == 'neutral']


    c2df = df[df['location'] == 'Chennai']
    posc2df = c2df[df['class'] == 'positive']
    negc2df = c2df[df['class'] == 'negative']
    neuc2df = c2df[df['class'] == 'neutral']


    c3df = df[df['location'] == 'Delhi']
    posc3df = c3df[df['class'] == 'positive']
    negc3df = c3df[df['class'] == 'negative']
    neuc3df = c3df[df['class'] == 'neutral']

    c4df = df[df['location'] == 'Kolkata']
    posc4df = c4df[df['class'] == 'positive']
    negc4df = c4df[df['class'] == 'negative']
    neuc4df = c4df[df['class'] == 'neutral']

    table = pd.DataFrame({'CITY':['MUMBAI','CHENNAI','DELHI','KOLKOTA'],
                          'POSITIVE':[len(posc1df) / len(c1df) * 100, len(posc2df) / len(c2df) * 100, len(posc3df) / len(c3df) * 100, len(posc4df) / len(c4df) * 100],
                          'NEGATIVE':[len(negc1df) / len(c1df) * 100, len(negc2df) / len(c2df) * 100, len(negc3df) / len(c3df) * 100, len(negc4df) / len(c4df) * 100],
                          'NEUTRAL':[len(neuc1df) / len(c1df) * 100, len(neuc2df) / len(c2df) * 100, len(neuc3df) / len(c3df) * 100, len(neuc4df) / len(c4df) * 100]
                          })
    return render_template("tables.html",data=table.to_html(index=False))


if __name__ == '__main__':
    app.secret_key = ".."
    app.run(debug=True)